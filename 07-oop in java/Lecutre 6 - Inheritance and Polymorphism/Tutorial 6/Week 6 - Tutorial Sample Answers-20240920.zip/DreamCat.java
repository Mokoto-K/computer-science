/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

public class DreamCat extends DreamPet{
    //EDIT Part 3.1
    Hair hairless;

    /**
     * @param breed    String representing the Pet's breed
     * @param sex      String (male or female)
     * @param deSexed  String (yes - de-sexed or no - not de-sexed)
     * @param purebred Enum Purebred representing yes/no/na
     * @param minAge   lowest age user would be willing to adopt
     * @param maxAge   highest age user would be willing to adopt
     * @param hairless Enum constant currently representing HAIRLESS or NA
     */
    //EDIT Part 3.2
    public DreamCat(String breed, Sex sex, DeSexed deSexed, Purebred purebred, int minAge, int maxAge, Hair hairless) {
        super(breed, sex, deSexed, purebred, minAge, maxAge);
        this.hairless=hairless;
    }

    /**
     * @param breed    String representing the Pet's breed
     * @param sex      String (male or female)
     * @param deSexed  String (yes - de-sexed or no - not de-sexed)
     * @param purebred Enum Purebred representing yes/no/na
     * @param hairless Enum constant currently representing HAIRLESS or NA
     */
    //EDIT Part 6.2
    public DreamCat(String breed, Sex sex, DeSexed deSexed, Purebred purebred, Hair hairless) {
        super(breed, sex, deSexed, purebred);
        this.hairless=hairless;
    }

    //EDIT Part 3.3
    /**
     * @return hairless Enum constant currently representing HAIRLESS or NA
     */
    public Hair getHairless() {
        return hairless;
    }

    //EDIT Part 3.4
    @Override
    public String getDreamPetDescription(){
        //this prints both the DreamPet features of the cat, e.g. breed etc. and the hairless field
        return super.getDreamPetDescription()+".\n > Hairless: "+this.getHairless();
    }

    //EDIT Part 3.5
    @Override
    public boolean compareDreamPets(DreamPet petCriteria) {
        //only allow this method to return true if the pet is a cat
        if(petCriteria instanceof DreamCat cat) {
            //if the DreamPet criteria don't match, return false
            if (!super.compareDreamPets(petCriteria)) return false;
            //if the user thinks hairless/not hairless is relevant, return true (match found)
            if(cat.getHairless().equals(Hair.NA)) return true;
            //if the user is concerned about hairless/not hairless, test if there is a match
            return this.getHairless().equals(cat.getHairless());
        }
        //if the pet isn't a cat, or the cat is not a match, return false
        return false;
    }
}
