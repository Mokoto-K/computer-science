/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

//EDIT Part 3.1
public enum Hair {
    HAIRLESS,NA;
    //useful design decision - Pinkman might want to add 'short-haired' or 'long haired' later
    //As it is, this enum is too short to justify creating it, however in view of future changes, it is a
    //good design choice to create it
    public String toString(){
        return switch (this) {
            case HAIRLESS -> "Hairless";
            default -> "Not Applicable";
        };
    }

}