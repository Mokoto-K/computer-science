/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

//EDIT Part 2
public class DreamDog extends DreamPet{

    //EDIT Part 2.1.1
    private LevelOfTraining levelOfTraining;
    private int amountOfExercise;

    /*
    /**
     * @param breed    String representing the Pet's breed
     * @param sex      String (male or female)
     * @param deSexed  String (yes - de-sexed or no - not de-sexed)
     * @param purebred Enum Purebred representing yes/no/na
     * @param minAge   lowest age user would be willing to adopt
     * @param maxAge   highest age user would be willing to adopt
     * @param levelOfTraining an Enum representing the level of training a dog is at
     * @param amountOfExercise an integer representing the daily exercise minutes required by this dog

    //EDIT Part 2.1.2 AND PART 6.3
    public DreamDog(String breed, Sex sex, DeSexed deSexed, Purebred purebred, int minAge, int maxAge, LevelOfTraining levelOfTraining, int amountOfExercise) {
        super(breed, sex, deSexed, purebred, minAge, maxAge);
        this.levelOfTraining=levelOfTraining;
        this.amountOfExercise=amountOfExercise;
    }
     */

    /**
     * @param breed    String representing the Pet's breed
     * @param sex      String (male or female)
     * @param deSexed  String (yes - de-sexed or no - not de-sexed)
     * @param purebred Enum Purebred representing yes/no/na
     * @param minAge   lowest age user would be willing to adopt
     * @param maxAge   highest age user would be willing to adopt
     */
    //EDIT Part 6.1
    public DreamDog(String breed, Sex sex, DeSexed deSexed, Purebred purebred, int minAge, int maxAge) {
        //only the superclass fields have to be initialised by this constructor
        super(breed, sex, deSexed, purebred, minAge, maxAge);
    }

    /**
     * @param breed    String representing the Pet's breed
     * @param sex      String (male or female)
     * @param deSexed  String (yes - de-sexed or no - not de-sexed)
     * @param purebred Enum Purebred representing yes/no/na
     * @param levelOfTraining an Enum representing the level of training a dog is at
     * @param amountOfExercise an integer representing the daily exercise minutes required by this dog
     */
    //EDIT Part 6.2
    public DreamDog(String breed, Sex sex, DeSexed deSexed, Purebred purebred, LevelOfTraining levelOfTraining, int amountOfExercise) {
        //only the superclass fields have to be initialised by this constructor
        super(breed, sex, deSexed, purebred);
        this.levelOfTraining=levelOfTraining;
        this.amountOfExercise=amountOfExercise;
    }

    //EDIT Part 2.1.3
    /**
     * @return the Dog's level of training from none to advanced (enum)
     */
    public LevelOfTraining getLevelOfTraining(){
        return this.levelOfTraining;
    }

    /**
     * @return an integer representing the daily exercise minutes required by this dog
     */
    public int getAmountOfExercise(){
        return this.amountOfExercise;
    }

    //EDIT Part 2.1.4
    @Override
    public String getDreamPetDescription(){
        //return both the superclass description and the dog specific fields
        return super.getDreamPetDescription()+".\n > Level of training: "+this.getLevelOfTraining()+
                ".\n > Exercise per day: "+this.getAmountOfExercise()+" minutes.";
    }

    //EDIT Part 2.1.5
    @Override
    public boolean compareDreamPets(DreamPet petCriteria) {
        //only return true if the pet is actually a dog and dreamPet features match!
        if(petCriteria instanceof DreamDog){
            return super.compareDreamPets(petCriteria);
        }
        return false;
    }
}
