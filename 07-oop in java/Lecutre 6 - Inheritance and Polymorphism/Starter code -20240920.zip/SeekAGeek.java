/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

import javax.swing.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SeekAGeek {
    //fields
    private static final String filePath = "./allGeeks.txt";
    private static AllGeeks allGeeks;
    //Like the new icon? 8D
    private static final String appName = "Seek A Geek 8D";
    private final static String iconPath = "./icon.png";
    private static final ImageIcon icon = new ImageIcon(iconPath);

    /**
     * main method used to interact with user - program simplified to only searching for a geek
     * checks if user is on file (valid username), if so, allows user to search for and get matching geek contact details
     * @param args none required
     */
    public static void main(String[] args) {
        allGeeks = loadGeeks();

        //welcome the user and ask them to sign in
        String username = (String) JOptionPane.showInputDialog(null,"Welcome to Seek A Geek! \n\nPlease enter your username:",appName, JOptionPane.QUESTION_MESSAGE, icon,null,null);
        if(username==null) System.exit(0); //terminate if they click x or cancel
        if(checkUsernameExists(username)) {
            DreamGeek dreamGeek = searchForGeek(); //if the user has a valid username, allow them to search for a match
            processSearchResults(dreamGeek, username); //show them any matches
        }
        System.exit(0); //always exit 'normally' at the end of the main method when using JOptionPane
    }

    //utility methods
    /**
     * method to load all the geek info from a file, using the data to instantiate an AllGeeks object
     * @return an AllGeeks object - this is a dataset of Geek objects
     */
    private static AllGeeks loadGeeks() {
        AllGeeks allGeeks = new AllGeeks();
        Path path = Path.of(filePath);
        List<String> eachGeek = null;
        try{
            eachGeek = Files.readAllLines(path);
        }catch (IOException io){
            System.out.println("The file could not be loaded. Check file path is correct. Terminating.\nError message: "+io.getMessage());
            System.exit(0);
        }

        for (int i=1;i<eachGeek.size();i++) {
            String[] elements = eachGeek.get(i).split("\\[");
            String[] geekInfo = elements[0].split(",");
            String username = geekInfo[0].replaceAll("\n", "");
            String name = geekInfo[1];

            int age = -1;
            try{
                age = Integer.parseInt(geekInfo[2]);
            }catch (NumberFormatException n){
                System.out.println("Error in file. Age could not be parsed for geek on line "+(i+1)+". Terminating. \nError message: "+n.getMessage());
                System.exit(0);
            }

            String phoneNumber=null;
            if(isValidPhoneNumber(geekInfo[3])) phoneNumber=geekInfo[3];
            else{
                System.out.println("Error in file. Phone number could not be parsed for geek on line "+(i+1)+". Terminating.");
                System.exit(0);
            }

            String emailAddress=null;
            if(isValidEmail(geekInfo[4])) emailAddress=geekInfo[4];
            else{
                System.out.println("Error in file. Email could not be parsed for geek on line "+(i+1)+". Terminating.");
                System.exit(0);
            }

            Gender gender = Gender.OTHER;
            try {
                gender = Gender.valueOf(geekInfo[5]);
            }catch (IllegalArgumentException e){
                System.out.println("Error in file. Gender could not be parsed for geek on line "+(i+1)+". Terminating. \nError message: "+e.getMessage());
                System.exit(0);
            }
            StarSign starSign = StarSign.CANCER;
            try{
                starSign = StarSign.valueOf(geekInfo[6].toUpperCase());
            }catch (IllegalArgumentException e){
                System.out.println("Error in file. Star sign could not be parsed for geek on line "+(i+1)+". Terminating. \nError message: "+e.getMessage());
                System.exit(0);
            }

            Religion religion = Religion.UNAFFILIATED;
            try{
                religion = Religion.valueOf(geekInfo[7].toUpperCase());
            }catch (IllegalArgumentException e){
                System.out.println("Error in file. Religion could not be parsed for geek on line "+(i+1)+". Terminating. \nError message: "+e.getMessage());
                System.exit(0);
            }

            String[] favouriteGames = elements[1].replace("]","").replace("\r","").split(",");
            Set<String> faveCompGames = new HashSet<>();
            for(String game: favouriteGames) faveCompGames.add(game.toLowerCase().strip());

            String[] faveTVShows = elements[2].replace("]","").replace("\r","").split(",");
            Set<String> favouriteTVShows = new HashSet<>();
            for(String tvShow: faveTVShows) favouriteTVShows.add(tvShow.toLowerCase().strip());

            String statement = elements[3].replace("],","");

            String blocked = elements[4].replace("]","").replace("\r","");
            Set<String> blockedGeeks = null;
            if(blocked.length()>0){
                blockedGeeks=new HashSet<>();
                String[] allBlocked = blocked.split(",");
                Collections.addAll(blockedGeeks, allBlocked);
            }

            DreamGeek dreamGeek = new DreamGeek(0,0,gender,starSign,religion,faveCompGames,favouriteTVShows);
            Geek g = new Geek(username,name,age,statement,blockedGeeks,phoneNumber,emailAddress,dreamGeek);
            allGeeks.addGeek(g);
        }
        return allGeeks;
    }

    /**
     * a regex matcher that ensures that the user's entry starts with a 0 and is followed by 9 digits
     * @param phoneNumber the candidate phone number entered by the user
     * @return true if phone number matches regex/false if not
     */
    public static boolean isValidPhoneNumber(String phoneNumber) {
        Pattern pattern = Pattern.compile("^0\\d{9}$");
        Matcher matcher = pattern.matcher(phoneNumber);
        return matcher.matches();
    }

    /**
     * a regex matcher that ensures that the user's entry complies with RFC 5322
     * source: <a href="https://www.baeldung.com/java-email-validation-regex">...</a>
     * @param email the candidate email entered by the user
     * @return true if email matches regex/false if not
     */
    public static boolean isValidEmail(String email) {
        Pattern pattern = Pattern.compile("^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$");
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    /**
     * verify whether the user is in the dataset
     * @param username the username entered by the Geek
     * @return true if username is in the dataset, false if not
     */
    private static boolean checkUsernameExists(String username){
        if(allGeeks.getGeek(username)==null) {
            JOptionPane.showMessageDialog(null,"No such username exists. Please rerun the program and select option 1 to sign up.");
            return false;
        }
        return true;
    }

    /**
     * obtains user input for the criteria they desire in a companion geek including age, star sign, gender and favourite games
     * uses this information to search the Geek dataset for compatible geeks. If there is a compatible Geek, the user is given the option
     * to contact the compatible geek. If there isn't, an appropriate message is provided to the user.
     * @return a DreamGeek object representing a user's 'perfect' match
     */
    private static DreamGeek searchForGeek(){
        //get user's desired age range
        int minAge = -1, maxAge = -1;
        while(minAge<18) {
            String userInput = (String) JOptionPane.showInputDialog(null,"What is the min age you desire? ",appName, JOptionPane.QUESTION_MESSAGE, icon,null,null);
            if(userInput==null) System.exit(0);
            try {
                minAge = Integer.parseInt(userInput);
            }
            catch (NumberFormatException e){
                JOptionPane.showMessageDialog(null,"Invalid input. Please try again.",appName, JOptionPane.ERROR_MESSAGE);
            }
            if(minAge<18) JOptionPane.showMessageDialog(null,"Age must be >= 18. Please try again.",appName, JOptionPane.ERROR_MESSAGE);
        }
        while(maxAge<minAge) {
            String userInput = (String) JOptionPane.showInputDialog(null,"What is the max age you desire? ",appName, JOptionPane.QUESTION_MESSAGE, icon,null,null);
            if(userInput==null) System.exit(0);
            try {
                maxAge = Integer.parseInt(userInput);
            }
            catch (NumberFormatException e){
                JOptionPane.showMessageDialog(null,"Invalid input. Please try again.",appName, JOptionPane.ERROR_MESSAGE);
            }
            if(maxAge<minAge) JOptionPane.showMessageDialog(null,"Max age must be greater than "+minAge+". Please try again.",appName, JOptionPane.ERROR_MESSAGE);
        }

        //get user's desired star sign, gender and religion
        StarSign starSign = (StarSign) JOptionPane.showInputDialog(null,"Please select your preferred star sign: ",appName, JOptionPane.QUESTION_MESSAGE,icon,StarSign.values(),StarSign.CAPRICORN);
        if(starSign==null) System.exit(0);
        Gender gender = (Gender) JOptionPane.showInputDialog(null,"Please select your preferred gender: ",appName, JOptionPane.QUESTION_MESSAGE,icon,Gender.values(),Gender.OTHER);
        if(gender==null) System.exit(0);
        Religion religion = (Religion) JOptionPane.showInputDialog(null,"Please select your preferred religion:",appName, JOptionPane.QUESTION_MESSAGE,icon,Religion.values(),Religion.UNAFFILIATED);
        if(religion==null) System.exit(0);

        //use a specialised method to collect user data for games and tv shows
        Set<String> favouriteGames = getUserFavouriteCollection("playing computer games","game");
        Set<String> favouriteTVShows = getUserFavouriteCollection("binging tv shows","tv show");

        //return the user's 'dream' geek
        return new DreamGeek(minAge,maxAge,gender,starSign,religion, favouriteGames, favouriteTVShows);
    }

    /**
     * a method that uses JOptionPane to get the user to enter their dream geek's favourite activities
     * @param activity a geeky activity, e.g., binging tv shows or playing computer games
     * @param item a singular geek item, e.g., game or tv show
     * @return a Set of Strings, where each String is one geek item
     */
    public static Set<String> getUserFavouriteCollection(String activity, String item){
        Set<String> items = new HashSet<>();
        String userInput = (String) JOptionPane.showInputDialog(null,"Would you like your dream geek to be into "+activity+"? (yes/no)",appName, JOptionPane.QUESTION_MESSAGE, icon,null,null);
        if(userInput==null) System.exit(0);
        if (userInput.equalsIgnoreCase("yes")) {
            userInput = (String) JOptionPane.showInputDialog(null,"Which "+item+" would you like your dream geek to be into? (enter done to finish)",appName, JOptionPane.QUESTION_MESSAGE, icon,null,null);
            while (!userInput.equalsIgnoreCase("done")) {
                items.add(userInput.toLowerCase());
                userInput = (String) JOptionPane.showInputDialog(null,"If there is another "+item+" you'd like to add, enter it or enter done to finish",appName, JOptionPane.QUESTION_MESSAGE, icon,null,null);
                if(userInput==null) System.exit(0);
            }
        } else items = null;
        return items;
    }

    /**
     * a method to display the user's matches (if there are any)
     * @param dreamGeek a DreamGeek object representing the user's 'dream' geek
     * @param username the user's unique, registered username
     */
    public static void processSearchResults(DreamGeek dreamGeek, String username){
        List<Geek> potentialMatches = allGeeks.findDreamGeek(dreamGeek, username);
        if (potentialMatches.size()==0) JOptionPane.showMessageDialog(null, "Sadly, no match meets your criteria.",appName, JOptionPane.INFORMATION_MESSAGE);
        else {
            String[] options = new String[potentialMatches.size()];
            StringBuilder infoToShow= new StringBuilder("You have the following potential matches: \n");
            for(int i=0;i<potentialMatches.size();i++){
                infoToShow.append(potentialMatches.get(i).getGeekDescription());
                options[i]=potentialMatches.get(i).getName();
            }
            String decision = (String) JOptionPane.showInputDialog(null,infoToShow+"\n\nPlease select which (if any) geek you'd like to contact:",appName, JOptionPane.QUESTION_MESSAGE,icon,options,options[0]);
            if(decision==null) {
                JOptionPane.showMessageDialog(null, "No one will not be informed or contacted about your search.",appName, JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            }
            else{
                for (Geek match : potentialMatches) {
                    if (decision.equals(match.getName()))
                        JOptionPane.showMessageDialog(null, match.getContactDetailsDescription(),appName, JOptionPane.INFORMATION_MESSAGE);
                }
            }

        }
    }

}
