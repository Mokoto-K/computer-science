/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

import java.util.HashMap;
import java.util.Map;

public class DreamPet {

    //EDIT Part 2.6.1
//    private final String breed;
//    private final Sex sex;
//    private final DeSexed deSexed;
//    private final Purebred purebred;

    //EDIT Part 2.6.2
    private final Map<Criteria,Object> petCriteria;
    private int minAge;
    private int maxAge;

    /**
     * constructor used to create user's dream pet (not real pet)
     * @param petCriteria a mapping of criteria to values, e.g. Breed: Jack russell
     * @param minAge lowest age user would be willing to adopt
     * @param maxAge highest age user would be willing to adopt
     */
    //EDIT Part 2.6.2
    public DreamPet(Map<Criteria,Object> petCriteria, int minAge, int maxAge) {
        //EDIT Part 2.6.1
//        this.breed = breed;
//        this.sex = sex;
//        this.deSexed = deSexed;
//        this.purebred=purebred;
        this.petCriteria=new HashMap<>(petCriteria); //EDIT Part 2.6.2
        this.minAge = minAge;
        this.maxAge = maxAge;
    }

    /**
     * constructor used to create real pet's dream pet features
     * @param petCriteria a mapping of criteria to values, e.g. Breed: Jack russell
     */
    //EDIT Part 2.6.2
    public DreamPet(Map<Criteria,Object> petCriteria){////EDIT Part 2.6.1 String breed, Sex sex, DeSexed deSexed, Purebred purebred) {
        this.petCriteria=new HashMap<>(petCriteria); //EDIT Part 2.6.2
        //EDIT Part 2.6.1
//        this.breed = breed;
//        this.sex = sex;
//        this.deSexed = deSexed;
//        this.purebred=purebred;
    }

//EDIT Part 2.6.1
//    /**
//     * @return the Pet's breed
//     */
//    public String getBreed() {
//        return breed;
//    }
//
//    /**
//     * @return the Pet's sex (male or female)
//     */
//    public Sex getSex() { return sex;}
//
//    /**
//     * @return the Pet's de-sexed status - true if de-sexed, false if not
//     */
//    public DeSexed isDeSexed() { return deSexed; }
//
//    /**
//     * @return Purebred constant yes (purebred), no(not purebred) or NA
//     */
//    public Purebred getPurebred() {
//        return purebred;
//    }


    //EDIT Part 2.6.2
    /**
     * access all the key-value pairs, e.g. breed: jack russell, sex: female, etc.
     * @return the entire mapping of criteria and their values
     */
    public Map<Criteria, Object> getAllPetCriteriaAndValues() {
        return new HashMap<>(petCriteria);
    }

    //EDIT Part 2.6.2
    /**
     * @param key a criteria, e.g. breed
     * @return the value at a specified criteria, e.g. jack russell
     */
    public Object getValueAtCriteria(Criteria key){
        return getAllPetCriteriaAndValues().get(key);
    }

    /**
     * @return a 'dream' Pet's min age
     */
    public int getMinAge() {
        return minAge;
    }
    /**
     * @return a 'dream' Pet's max age
     */
    public int getMaxAge() {
        return maxAge;
    }

    //EDIT Part 2.6.3
    /**
     * method to return a description of generic DreamPet features
     * @return a formatted String description of the pet's dream features
     */
    public String getDreamPetDescription(Map<Criteria,Object> criteria){
        StringBuilder description= new StringBuilder();
        //iterate through the criteria the user is interested in, creating a String description of compatible pets
        for(Criteria key: criteria.keySet()) description.append("\n").append(key).append(": ").append(getValueAtCriteria(key));
        return description.toString();
    }

    //EDIT Part 2.6.4
    /**
     * method to compare two DreamPet objects against each other for compatibility
     * @param petCriteria an imaginary pet representing the user's criteria
     * @return true if matches, false if not
     */
    public boolean compareDreamPets(DreamPet petCriteria) {
        for(Criteria key : petCriteria.getAllPetCriteriaAndValues().keySet()) {
            //if the values don't match, the pets are not compatible
            if(!getValueAtCriteria(key).equals(petCriteria.getValueAtCriteria(key))) return false;
        }
        return true;
    }
}