/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

import javax.swing.*;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

//Part 2
public class Basic implements Subscription{

    //Part 4.1: this Map will contain user selections
    private final Map<Criteria,Object> criteria;
    //Part 4.2: number of results shown to basic users
    private final int numberOfSearchResultsToShow;

    //Part 4.3
    /**
     * creates instance of Basic class
     * @param numberOfSearchResultsToShow number of results shown to basic users
     */
    public Basic(int numberOfSearchResultsToShow){
        this.numberOfSearchResultsToShow=numberOfSearchResultsToShow;
        this.criteria = new HashMap<>();
    }

    /**
     * method to get user to input filter information to choose their pet
     * @param petType   the type of pet, e.g. cat, dog (PetType enum)
     * @param allBreeds a Set</String> of the breeds corresponding to the pet type
     * @return a DreamPet object representing the user's imagined, perfect pet
     */
    @Override
    //Part 4.4
    public DreamPet getUserInput(PetType petType, Set<String> allBreeds) {
        criteria.put(Criteria.TYPE,petType);
        String breed = getUserInputBreed(allBreeds);
        if(!breed.equals("NA")) criteria.put(Criteria.BREED, breed);
        criteria.put(Criteria.DE_SEXED,getUserInputDeSexed());
        double[] ageRange = getUserInputAgeRange();
        //Part 4.4.3: show the advertisement, using Subscription's constants
        JOptionPane.showMessageDialog(null,"Premium subscribers can also search based on sex, purebred, hair type and adoption fee! " +
                "Subscribe today for only $"+premiumSubscriptionFee,appName,JOptionPane.INFORMATION_MESSAGE);
        return new DreamPet(criteria,ageRange[0],ageRange[1]);
    }
    /**
     * method to show the user formatted output of all the pets that meet their criteria, allowing them to choose one or none
     * @param potentialMatches a List of Pet objects corresponding to real pets that meet the user's criteria
     * @param criteria       all the constants in the Criteria enum (used for outputting values, given the Criteria constants are keys)
     * @return the user's chosen Pet
     */
    @Override
    public Pet displayResults(List<Pet> potentialMatches, Criteria[] criteria) {
        Map<String,Pet> options = new HashMap<>();
        int limit = Math.min(numberOfSearchResultsToShow,potentialMatches.size());
        //Part 4.5.1-2
        StringBuilder infoToShow = new StringBuilder("We have found "+potentialMatches.size()+" matches!! A maximum of only "+numberOfSearchResultsToShow+" results can be shown on the Basic plan. Please subscribe today to see all results! \n");
        for (int i=0;i<limit;i++){
            infoToShow.append("\n").append(potentialMatches.get(i).toString(criteria)); //Part 4.5.3
            options.put(potentialMatches.get(i).name() + " (" + potentialMatches.get(i).microchipNumber() + ")", potentialMatches.get(i));
        }
        String adopt = (String) JOptionPane.showInputDialog(null,infoToShow+"\nPlease select which " +
                "Pet you'd like to adopt:",appName, JOptionPane.QUESTION_MESSAGE,icon,options.keySet().toArray(), "");
        if(adopt==null) System.exit(0);
        else {
            //Part 4.5.4: If the user chooses to adopt a pet, calculate 10% of the pet's adoption fee, and tell the user they could save this today,
            // as well as the subscription fee, and the $100 vet voucher for premium users. Show the advertisement using Subscriber's constants
            //formatting helps 'prettify' the output
            DecimalFormat df = new DecimalFormat("0.00");
            JOptionPane.showMessageDialog(null, "Premium subscribers get a $100 voucher for their new pet's first visit to the vet. " +
                            "They also get 10% off their adoption fee!" +
                            "Subscribe today for only $" + premiumSubscriptionFee + " and save $" + df.format(premiumUserDiscount*options.get(adopt).adoptionFee()) + " on your adoption fee today!"
                    , appName, JOptionPane.INFORMATION_MESSAGE);
        }
        return options.get(adopt);
    }
    /**
     * a method to write the user's contact info and the info of the pet they want to a file
     * @param pet the user's chosen pet
     */
    @Override
    public void placeAdoptionRequest(Pet pet) {
        //Part 4.6.1 because basic users don't have info on file, ask them to input it using the default methods
        String name = getUsersName();
        String phoneNumber=getUsersPhoneNumber();
        String email = getUsersEmail();
        Person user = new Person(name,phoneNumber,email);
        //Part 4.6.2
        writeAdoptionRequestToFile(user, pet, "basic_");
    }
}
