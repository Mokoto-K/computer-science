/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

import javax.swing.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FindAPet {

    //private final static String appName = "Pinkman's Pets Pet Finder";
    private final static String filePath = "./allPets.txt";
    //private final static String iconPath = "./icon.jpg";
    //private static final ImageIcon icon = new ImageIcon(iconPath);
    private static AllPets allPets;

    /**
     * main method used to allow the user to search Pinkman's database of Pets, and place an adoption request
     * @param args none required
     */
    public static void main(String[] args) {
        allPets = loadPets();
        JOptionPane.showMessageDialog(null, "Welcome to Pinkman's Pets Pet Finder!\n\tTo start, click OK.", Subscription.appName, JOptionPane.QUESTION_MESSAGE, Subscription.icon);

        //Part 3.1: ask the user whether they have an account
        String account = (String) JOptionPane.showInputDialog(null,"Do you have an account with us?",Subscription.appName,JOptionPane.QUESTION_MESSAGE,Subscription.icon,new String[]{"Yes", "No"},"");
        ////Part 3.2: depending on whether they chose yes or no, create a premium or basic object, initialising each appropriately
        Subscription user;
        if(account.equals("Yes")) user = new Premium("./premiumUsers.txt");
        else user = new Basic(3); //Part 4.3

        //EDIT 3.3: use the default method in Subscription to get the user's type
        PetType type = user.getUserInputType();
        //create a DreamPet object, initialising it with a call to getUserInput (pass in a method)
        //call to AllPets getAllBreeds to populate the Set<String> of breeds for the user to choose
        //from. See how clunky this is compared to using enums?
        DreamPet petCriteria = user.getUserInput(type,allPets.getAllBreeds(type));

        //DreamPet petCriteria = getUserCriteria();
        processSearchResults(petCriteria,user);
        System.exit(0);
    }
    /**
     * method to load all Pet data from file, storing it as Pet objects in an instance of AllPets
     * @return an AllPets object - functions as database of Pets, with associated methods
     */
    private static AllPets loadPets() {
        AllPets allPets = new AllPets();
        Path path = Path.of(filePath);

        List<String> petData = null;
        try{
            petData = Files.readAllLines(path);
        }catch (IOException io){
            System.out.println("Could not load the file. \nError message: "+io.getMessage());
            System.exit(0);
        }
        for (int i=1;i<petData.size();i++) {
            String[] elements = petData.get(i).split(",");
            PetType type = null;
            try {
                //EDIT Part 3.3: ensure that when you read the file, you also replace whitespace with underscore
                type = PetType.valueOf(elements[0].toUpperCase().replace(" ","_"));
            }catch (IllegalArgumentException e){
                System.out.println("Error in file. Type of pet data could not be parsed for pet on line "+(i+1)+ ". Terminating. \nError message: "+e.getMessage());
                System.exit(0);
            }

            String name = elements[1];
            long microchipNumber = 0;
            try{
                microchipNumber = Long.parseLong(elements[2]);
            }
            catch (NumberFormatException n){
                System.out.println("Error in file. Microchip number could not be parsed for Pet on line "+(i+1)+". Terminating. \nError message: "+n.getMessage());
                System.exit(0);
            }

            Sex sex = Sex.valueOf(elements[3].toUpperCase());//add exception handling here
            DeSexed deSexed = DeSexed.valueOf(elements[4].toUpperCase()); //add exception handling here

            int age = 0;
            try{
                age = Integer.parseInt(elements[5]);
            }catch (NumberFormatException n){
                System.out.println("Error in file. Age could not be parsed for Pet on line "+(i+1)+". Terminating. \nError message: "+n.getMessage());
                System.exit(0);
            }

            String breed = elements[6].toLowerCase();
            Purebred purebred = Purebred.valueOf(elements[7].toUpperCase()); //add exception handling here

            double adoptionFee = 0;
            try{
                adoptionFee = Double.parseDouble(elements[8]);
            }catch (NumberFormatException n){
                System.out.println("Error in file. Adoption fee could not be parsed for Pet on line "+(i+1)+". Terminating. \nError message: "+n.getMessage());
                System.exit(0);
            }

            Hair hair  = Hair.valueOf(elements[9].toUpperCase()); //add exception handling here
            LevelOfTraining trainingLevel = LevelOfTraining.valueOf(elements[10].toUpperCase()); //add exception handling here
            int dailyExercise = 0;
            if(!elements[11].equalsIgnoreCase("NA"))
                try{
                    dailyExercise = Integer.parseInt(elements[11]);
                }catch (NumberFormatException n){
                    System.out.println("Error in file. Exercise minutes could not be parsed for Pet on line "+(i+1)+". Terminating. \nError message: "+n.getMessage());
                    System.exit(0);
                }

            Map<Criteria,Object> petCriteria = new HashMap<>();
            petCriteria.put(Criteria.TYPE,type);
            petCriteria.put(Criteria.SEX,sex);
            petCriteria.put(Criteria.DE_SEXED,deSexed);
            petCriteria.put(Criteria.BREED,breed);
            petCriteria.put(Criteria.PUREBRED,purebred);
            petCriteria.put(Criteria.HAIR,hair);
            petCriteria.put(Criteria.TRAINING_LEVEL,trainingLevel);
            petCriteria.put(Criteria.DAILY_EXERCISE,dailyExercise);

            DreamPet dreamPet = new DreamPet(petCriteria);
            Pet Pet = new Pet(name, microchipNumber,age, adoptionFee,dreamPet);

            allPets.addPet(Pet);
        }
        return allPets;
    }

//    /**
//     * method to get user to input name, ph num and email, with appropriate input validation
//     * @return a Person object representing the user of the program
//     */
//    private static Person getUserDetails(){
//        String name;
//        do {
//            name = JOptionPane.showInputDialog(null, "Please enter your full name.", appName, JOptionPane.QUESTION_MESSAGE);
//            if(name==null) System.exit(0);
//        }while (!name.contains(" "));
//
//        long phoneNumber = 0;
//        String phoneNumberInput;
//        do {
//            phoneNumberInput = JOptionPane.showInputDialog(null,"Please enter your phone number. Format: 0412838475",appName,JOptionPane.QUESTION_MESSAGE);
//            if (phoneNumberInput == null) System.exit(0);
//            try {
//                phoneNumber = Long.parseLong(phoneNumberInput);
//            } catch (NumberFormatException n) {
//                JOptionPane.showMessageDialog(null, "Invalid entry. Please enter your 10 digit phone number.");
//            }
//        }while(phoneNumberInput.length()!=10);
//
//        String email;
//        do {
//            email = JOptionPane.showInputDialog(null, "Please enter your email address.", appName, JOptionPane.QUESTION_MESSAGE);
//            if(email==null) System.exit(0);
//        }while (!email.contains("@"));
//
//        return new Person(name, phoneNumber, email);
//    }

//    No longer needed:
//    /**
//     * generates JOptionPanes requesting user input for Pet breed, sex, de-sexed status and age
//     * @return a DreamPet object representing the user's desired Pet criteria
//     */
//    private static DreamPet getUserCriteria(){
//        PetType type = (PetType) JOptionPane.showInputDialog(null,"Please select the type of pet you'd like to adopt.",appName, JOptionPane.QUESTION_MESSAGE,icon,PetType.values(), PetType.DOG);
//        if(type==null) System.exit(0);
//
//        String breed  = (String) JOptionPane.showInputDialog(null,"Please select your preferred breed.",appName, JOptionPane.QUESTION_MESSAGE,icon,allPets.getAllBreeds(type).toArray(),"");
//        if(breed==null) System.exit(0);
//
//        Sex sex = (Sex) JOptionPane.showInputDialog(null,"Please select your preferred sex:",appName, JOptionPane.QUESTION_MESSAGE,icon,Sex.values(),Sex.FEMALE);
//        if(sex==null) System.exit(0);
//        DeSexed deSexed = (DeSexed) JOptionPane.showInputDialog(null,"Would you like your Pet to be de-sexed or not?",appName, JOptionPane.QUESTION_MESSAGE,icon,DeSexed.values(),DeSexed.YES);
//        if(deSexed==null) System.exit(0);
//        Purebred purebred  = (Purebred) JOptionPane.showInputDialog(null,"Would you like the Pet to be a purebred?",appName, JOptionPane.QUESTION_MESSAGE,null,Purebred.values(), "");
//        if(purebred==null) System.exit(0);
//
//        double[] ageRange = minMaxValues("What is the age (years) of the youngest Pet you'd like to adopt?","What is the age (years) of the oldest Pet you'd be willing to adopt?");
//
//        Map<Criteria,Object> desiredFeatures = new HashMap<>();
//        desiredFeatures.put(Criteria.TYPE, type);
//        if(!breed.equals("NA")) desiredFeatures.put(Criteria.BREED,breed);
//        if(!sex.equals(Sex.NA)) desiredFeatures.put(Criteria.SEX,sex);
//        desiredFeatures.put(Criteria.DE_SEXED,deSexed);
//        if(!purebred.equals(Purebred.NA)) desiredFeatures.put(Criteria.PUREBRED,purebred);
//
//        if(type.equals(PetType.CAT)||type.equals(PetType.GUINEA_PIG)){
//            Hair hair  = (Hair) JOptionPane.showInputDialog(null,"Please select from the following options","Pinkman's Pet Finder", JOptionPane.QUESTION_MESSAGE,null,Hair.values(), "");
//            if(hair==null) System.exit(0);
//            if(!hair.equals(Hair.NA)) desiredFeatures.put(Criteria.HAIR,hair);
//        }
//        double[] feeRange = minMaxValues("What is the lowest adoption fee you're interested in? ","What is the max. adoption fee you're willing to pay?");
//
//        return new DreamPet(desiredFeatures,ageRange[0],ageRange[1],feeRange[0],feeRange[1]);
//    }

//    /**
//     * a method to get the user to enter a value range (min - max)
//     * @param minMessage the message to the user asking them to input a min value
//     * @param maxMessage the message to the user asking them to input a max value
//     * @return an int[] array where [0] is min and [1] is max
//     */
//    public static double[] minMaxValues(String minMessage, String maxMessage){
//        double[] range = {-1,-1};
//        while(range[0]<0) {
//            String input = JOptionPane.showInputDialog(null, minMessage, appName, JOptionPane.QUESTION_MESSAGE);
//            if(input==null) System.exit(0);
//            try {
//                range[0] = Double.parseDouble(input);
//                if(range[0]<0) JOptionPane.showMessageDialog(null,"Min. must be >= 0.",appName, JOptionPane.ERROR_MESSAGE);
//            }
//            catch (NumberFormatException e){
//                JOptionPane.showMessageDialog(null,"Invalid input. Please try again.", appName, JOptionPane.ERROR_MESSAGE);
//            }
//        }
//        while(range[1]<range[0]) {
//            String input = JOptionPane.showInputDialog(null, maxMessage, appName, JOptionPane.QUESTION_MESSAGE);
//            if(input==null) System.exit(0);
//            try {
//                range[1] = Double.parseDouble(input);
//                if(range[1]<range[0]) JOptionPane.showMessageDialog(null,"Max must be >= "+range[0],appName, JOptionPane.ERROR_MESSAGE);
//            }
//            catch (NumberFormatException e){
//                JOptionPane.showMessageDialog(null,"Invalid input. Please try again.", appName, JOptionPane.ERROR_MESSAGE);
//            }
//        }
//        return range;
//    }

    /**
     * method to display  results (if there are any) to the user in the form of a drop-down list
     * allowing them to select and adopt a pet of their choice.
     * @param dreamPet a DreamPet object representing the user's selections
     * @param user a Premium or Basic object (code to the Subscription interface) representing the type of user
     */
    private static void processSearchResults(DreamPet dreamPet,Subscription user) {
        List<Pet> potentialMatches = allPets.findMatch(dreamPet);
        if (potentialMatches.size() > 0) {
//            Map<String,Pet> options = new HashMap<>();
//            StringBuilder infoToShow = new StringBuilder("Matches found!! The following Pets meet your criteria: \n");
//            for (Pet potentialMatch : potentialMatches) {
//                infoToShow.append("\n").append(potentialMatch.getPetDescription(dreamPet.getAllPetCriteriaAndValues()));
//                options.put(potentialMatch.getName() + " (" + potentialMatch.getMicrochipNumber() + ")", potentialMatch);
//            }
//            String adopt = (String) JOptionPane.showInputDialog(null,infoToShow+"\nPlease select which " +
//                    "Pet you'd like to adopt:",appName, JOptionPane.QUESTION_MESSAGE,icon,options.keySet().toArray(), "");
//            if(adopt==null) System.exit(0);
//            else{
//                Pet chosenPet = options.get(adopt);
//                Person applicant = getUserDetails();
//                writeAdoptionRequestToFile(applicant, chosenPet);
            //Part 3.6
            Pet chosenPet = user.displayResults(potentialMatches, Criteria.values());
            user.placeAdoptionRequest(chosenPet);
            JOptionPane.showMessageDialog(null, "Thank you! Your adoption request has been submitted. \n" +
                    "One of our friendly staff will be in touch shortly.", Subscription.appName, JOptionPane.QUESTION_MESSAGE, Subscription.icon);
        }//Part 3.7
        else JOptionPane.showMessageDialog(null, "Unfortunately none of our pets meet your criteria :(" +
                "\n\tTo exit, click OK.", Subscription.appName, JOptionPane.QUESTION_MESSAGE, Subscription.icon);
    }
}
