/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

import javax.swing.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//Part 1: First, create the Subscription interface, including 3 method headers
public interface Subscription {

    //Part 1.2: these are constants - they are public and static, and can be used across the entire program
    String appName  = "Pinkman's Pets Pet Finder";
    ImageIcon icon = new ImageIcon("./icon.jpg");
    //Part 1.3: these values may change in the future, so putting them here is a good way to make future changes easy to implement
    double premiumSubscriptionFee = 14.99;
    double premiumUserDiscount = 0.1;
    double voucherAmount = 100;

    //Part 1.1
    /**
     * method to get user to input filter information to choose their pet
     * @param petType the type of pet, e.g. cat, dog (PetType enum)
     * @param allBreeds a Set</String> of the breeds corresponding to the pet type
     * @return a DreamPet object representing the user's imagined, perfect pet
     */
    DreamPet getUserInput(PetType petType, Set<String> allBreeds);

    //Part 1.2
    /**
     * method to show the user formatted output of all the pets that meet their criteria, allowing them to choose one or none
     * @param compatiblePets an ArrayList of Pet objects corresponding to real pets that meet the user's criteria
     * @param criteria all the constants in the Criteria enum (used for outputting values, given the Criteria constants are keys)
     * @return the user's chosen Pet
     */
    Pet displayResults(List<Pet> compatiblePets, Criteria[] criteria);

    //Part 1.3
    /**
     * a method to write the user's contact info and the info of the pet they want to a file
     * @param pet the user's chosen pet
     */
    void placeAdoptionRequest(Pet pet);

    //Part 1.4
    //These are default methods that be used across all implementations of this interface
    //default methods are methods whose implementation will not vary across implementing classes
    //Note the use of the constants in the JOptionPane
    //Note how useful enums are now! Because they are a set of constants, they can be used anywhere in the program

    /**
     * a method to get the user to select which kind of pet they want from a predefined list
     * @return PetType  (enum) representing the type of pet, e.g. cat or dog
     */
    default PetType getUserInputType() {
        PetType type = (PetType) JOptionPane.showInputDialog(null,"Please select the type of pet you'd like to adopt.",appName, JOptionPane.QUESTION_MESSAGE,icon,PetType.values(), PetType.DOG);
        if(type==null) System.exit(0);
        return type;
    }

    /**
     * a method to get the user to select which breed of pet they want from a predefined list
     * @param allBreeds a Set of Strings representing all the breeds of a given type of pet
     * @return a String representing the chosen breed, e.g. jack russell
     */
    default String getUserInputBreed(Set<String> allBreeds) {
        String breed = (String) JOptionPane.showInputDialog(null, "Please select your preferred breed.", appName, JOptionPane.QUESTION_MESSAGE, icon, allBreeds.toArray(), "");
        if (breed == null) System.exit(0);
        return breed;
    }

    /**
         * a method to get the user to select whether they want their pet to be purebred (or NA)
         * @return Purebred (enum) of YES, NO, NA
         */
    default Purebred getUserInputPurebred() {
        Purebred purebred = (Purebred) JOptionPane.showInputDialog(null, "Would you like the Pet to be a purebred?", appName, JOptionPane.QUESTION_MESSAGE, null, Purebred.values(), "");
        if (purebred == null) System.exit(0);
        return purebred;
    }

    /**
     * a method to get the user to select their preferred sex (or NA)
     * @return Sex (enum) MALE, FEMALE or NA
     */
    default Sex getUserInputSex() {
        Sex sex = (Sex) JOptionPane.showInputDialog(null, "Please select your preferred sex:", appName, JOptionPane.QUESTION_MESSAGE, icon, Sex.values(), Sex.FEMALE);
        if (sex == null) System.exit(0);
        return sex;
    }

    /**
     * a method to get the user to select whether they want their pet to be de-sexed
     * @return Purebred (enum) of YES, NO
     */
    default DeSexed getUserInputDeSexed() {
        DeSexed deSexed = (DeSexed) JOptionPane.showInputDialog(null, "Would you like your Pet to be de-sexed or not?", appName, JOptionPane.QUESTION_MESSAGE, icon, DeSexed.values(), DeSexed.YES);
        if (deSexed == null) System.exit(0);
        return deSexed;
    }

    /**
     * a method to get the user to select what hair type they want, e.g. short, long, hairless
     * @return Hair enum representing user's choice
     */
    default Hair getUserInputHairType() {
        Hair hair = (Hair) JOptionPane.showInputDialog(null, "Please select from the following options", "Pinkman's Pet Finder", JOptionPane.QUESTION_MESSAGE, null, Hair.values(), "");
        if (hair == null) System.exit(0);
        return hair;
    }

    /**
     * method to get user to select age range (min - max)
     * @return an int array where [0] is min age and [1] is max age
     */
    default double[] getUserInputAgeRange(){
        return minMaxValues("What is the age (years) of the youngest Pet you'd like to adopt?","What is the age (years) of the oldest Pet you'd be willing to adopt?");
    }

    /**
     * method to get user to select adoption fee range (min - max)
     * @return an int array where [0] is min fee and [1] is max fee
     */
    default double[] getUserInputFeeRange(){
        return minMaxValues("What is the lowest adoption fee you're interested in? ","What is the max. adoption fee you're willing to pay?");
    }

    /**
     * a method to get the user to enter a value range (min - max)
     * @param minMessage the message to the user asking them to input a min value
     * @param maxMessage the message to the user asking them to input a max value
     * @return an int[] array where [0] is min and [1] is max
     */
    private double[] minMaxValues(String minMessage, String maxMessage){ //private methods are allowed in interfaces since Java 9
        double[] range = {-1,-1};
        while(range[0]<0) {
            String input = JOptionPane.showInputDialog(null, minMessage, appName, JOptionPane.QUESTION_MESSAGE);
            if(input==null) System.exit(0);
            try {
                range[0] = Double.parseDouble(input);
                if(range[0]<0) JOptionPane.showMessageDialog(null,"Min. must be >= 0.",appName, JOptionPane.ERROR_MESSAGE);
            }
            catch (NumberFormatException e){
                JOptionPane.showMessageDialog(null,"Invalid input. Please try again.", appName, JOptionPane.ERROR_MESSAGE);
            }
        }
        while(range[1]<range[0]) {
            String input = JOptionPane.showInputDialog(null, maxMessage, appName, JOptionPane.QUESTION_MESSAGE);
            if(input==null) System.exit(0);
            try {
                range[1] = Double.parseDouble(input);
                if(range[1]<range[0]) JOptionPane.showMessageDialog(null,"Max must be >= "+range[0],appName, JOptionPane.ERROR_MESSAGE);
            }
            catch (NumberFormatException e){
                JOptionPane.showMessageDialog(null,"Invalid input. Please try again.", appName, JOptionPane.ERROR_MESSAGE);
            }
        }
        return range;
    }

    //Part 1.5: methods to get user's contact info
    /**
     * a method to get the user to enter their full name
     * @return a String representing the user's name
     */
    default String getUsersName(){
        String name;
        do {
            name = JOptionPane.showInputDialog(null, "Please enter your full name.", appName, JOptionPane.QUESTION_MESSAGE);
            if(name==null) System.exit(0);
        } while(!isValidFullName(name));
        return name;
    }

    /**
     * a method to get the user to enter their phone number
     * @return a String representing the user's phone number
     */
    default String getUsersPhoneNumber(){
        String phoneNumber;
        do{
            phoneNumber = JOptionPane.showInputDialog("Please enter your phone number (10-digit number in the format 0412345678): ");
            if(phoneNumber==null) System.exit(0);}
        while(!isValidPhoneNumber(phoneNumber));
        return phoneNumber;
    }

    /**
     * a method to get the user to enter their email address
     * @return a String representing the user's email address
     */
    default String getUsersEmail() {
        String email;
        do {
            email = JOptionPane.showInputDialog(null, "Please enter your email address.", appName, JOptionPane.QUESTION_MESSAGE);
            if (email == null) System.exit(0);
        }while(!isValidEmail(email));
        return email;
    }

    /**
     * a very simple regex for full name in Firstname Surname format
     * @param fullName the candidate full name entered by the user
     * @return true if name matches regex/false if not
     */
    private boolean isValidFullName(String fullName) {
        String regex = "^[A-Z][a-z]+\\s[A-Z][a-zA-Z]+$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(fullName);
        return matcher.matches();
    }

    /**
     * a regex matcher that ensures that the user's entry starts with a 0 and is followed by 9 digits
     * @param phoneNumber the candidate phone number entered by the user
     * @return true if phone number matches regex/false if not
     */
    default boolean isValidPhoneNumber(String phoneNumber) {
        Pattern pattern = Pattern.compile("^0\\d{9}$");
        Matcher matcher = pattern.matcher(phoneNumber);
        return matcher.matches();
    }

    /**
     * a regex matcher that ensures that the user's entry complies with RFC 5322
     * source: <a href="https://www.baeldung.com/java-email-validation-regex">...</a>
     * @param email the candidate email entered by the user
     * @return true if email matches regex/false if not
     */
    private boolean isValidEmail(String email) {
        Pattern pattern = Pattern.compile("^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$");
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    /**
     * provides Pinkman's Pets with a file containing the user's adoption request
     * @param person a Person object representing the user
     * @param Pet a Pet object representing the Pet that the user wants to adopt
     * @param preface a String that prefaces the file name
     */
    //Part 1.6
    default void writeAdoptionRequestToFile(Person person, Pet Pet, String preface) {
        String filePath = preface+person.name().replace(" ","_")+"_adoption_request.txt";
        Path path = Path.of(filePath);
        String lineToWrite = person.name()+" wishes to adopt "+Pet.name()+" ("+Pet.microchipNumber()+
                "). Their phone number is "+person.phoneNumber()+" and their email address is "+person.emailAddress();
        try {
            Files.writeString(path, lineToWrite);
        }catch (IOException io){
            System.out.println("File could not be written. \nError message: "+io.getMessage());
            System.exit(0);
        }
    }
}
