/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

import javax.swing.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.DecimalFormat;
import java.util.*;

//Part 2
public class Premium implements Subscription{

    //Part 2.1: this Map will contain user selections
    private final Map<Criteria,Object> criteria;
    //Part 2.2: this String represents the file path of the txt file containing premium user info
    private final String premiumUserDataFile;
    //Part 2.3: this Map will connect emails to Person objects, allowing us to check whether a user is premium or not
    private final Map<String,Person> premiumUsers;

    //Part 2.4
    /**
     * constructor to create instance of Premium class
     * @param premiumUserFilePath the txt file containing premium user info
     */
    public Premium(String premiumUserFilePath){
        this.premiumUserDataFile = premiumUserFilePath;
        //use the constructor to initialise fields (inc. default values)
        criteria = new HashMap<>();
        premiumUsers = new HashMap<>();
    }

    /**
     * method to get user to input filter information to choose their pet
     * @param petType   the type of pet, e.g. cat, dog (PetType enum)
     * @param allBreeds a Set</String> of the breeds corresponding to the pet type
     * @return a DreamPet object representing the user's imagined, perfect pet
     */
    @Override
    public DreamPet getUserInput(PetType petType, Set<String> allBreeds) {
        //Part 2.5
        criteria.put(Criteria.TYPE,petType);
        //Part 2.5.3
        String breed = getUserInputBreed(allBreeds);
        //only add the user's choice to the Map if it is not NA (this eliminates redundant comparisons)
        if(!breed.equals("NA")) criteria.put(Criteria.BREED, breed);
        Purebred purebred = getUserInputPurebred();
        if(!purebred.equals(Purebred.NA)) criteria.put(Criteria.PUREBRED,purebred);
        //Part 2.5.2: only ask the user for hair input if the pet type is guinea pig or cat
        if(petType.equals(PetType.CAT) || petType.equals(PetType.GUINEA_PIG)) criteria.put(Criteria.HAIR,getUserInputHairType());
        Sex sex = getUserInputSex();
        if(!sex.equals(Sex.NA)) criteria.put(Criteria.SEX,sex);
        criteria.put(Criteria.DE_SEXED,getUserInputDeSexed());
        double[] ageRange = getUserInputAgeRange();
        double[] feeRange = getUserInputFeeRange();
        return new DreamPet(criteria,ageRange[0],ageRange[1],feeRange[0], feeRange[1]);
    }

    /**
     * method to show the user formatted output of all the pets that meet their criteria, allowing them to choose one or none
     * @param potentialMatches an ArrayList of Pet objects corresponding to real pets that meet the user's criteria
     * @param criteria       all the constants in the Criteria enum (used for outputting values, given the Criteria constants are keys)
     * @return the user's chosen Pet
     */
    @Override
    public Pet displayResults(List<Pet> potentialMatches, Criteria[] criteria) {
        //Part 2.6.1
        Map<String,Pet> options = new HashMap<>();
        //Part 2.6.2
        StringBuilder infoToShow = new StringBuilder("Matches found!! The following Pets meet your criteria: \n");
        for (Pet potentialMatch : potentialMatches) {
            infoToShow.append("\n").append(potentialMatch.toString(criteria)); //Part 2.6.3
            options.put(potentialMatch.name() + " (" + potentialMatch.microchipNumber() + ")", potentialMatch);
        }
        //Part 2.6.4
        String adopt = (String) JOptionPane.showInputDialog(null,infoToShow+"\nPlease select which " +
                "Pet you'd like to adopt:",appName, JOptionPane.QUESTION_MESSAGE,icon,options.keySet().toArray(), "");
        if(adopt==null) System.exit(0);
        return options.get(adopt); //Part 2.6.5
    }

    /**
     * a method to write the user's contact info and the info of the pet they want to a file
     * @param pet the user's chosen pet
     */
    @Override
    public void placeAdoptionRequest(Pet pet) {
        //Part 2.8.1: first get the user's email (this will be used to verify if they are premium users)
        String userEmail = getUsersEmail();
        //if the file didn't load, we're not sure if the user really is 'premium' so a preface will tell Pinkman to check his database manually
        String preface = "";
        //if the file didn't load, use the default methods to get the user's contact info, so that they can still place their adoption request
        Person user;
        if(!this.loadPremiumData()) { //Part 2.8.2 - data couldn't load, so manually get user data
            //Part 2.8.3
            JOptionPane.showMessageDialog(null,"No account found! Please enter your contact details!",appName, JOptionPane.QUESTION_MESSAGE,icon);
            user = new Person(getUsersName(),getUsersPhoneNumber(),userEmail);
            preface="unverified_";//Part 2.8.3
        }
        else{
            //Part 2.8.4: if the file loads, but the user's info isn't in it, tell the user that their acct couldn't be found.
            if(!premiumUsers.containsKey(userEmail)){
                JOptionPane.showMessageDialog(null,"No premium account with email "+ userEmail +" found! " +
                        "\nTry again with the basic functionality, or sign up for a premium account. Terminating...",appName, JOptionPane.QUESTION_MESSAGE);
                return;
            }
            else user = premiumUsers.get(userEmail); //Part 2.8.5
        }
        //Part 2.8.5: if the acct couldn't be verified, it'll be prefaced by 'unverified', otherwise, it will simply be 'premium user'
        preface+="premium_user_";
        writeAdoptionRequestToFile(user, pet, preface);

        //Part 2.8.7
        //formatting helps 'prettify' the output
        DecimalFormat df = new DecimalFormat("0.00");
        JOptionPane.showMessageDialog(null,
                "Congratulations "+ user.name().split(" ")[0]+"! As a premium member, you get a $"+df.format(voucherAmount)+" voucher for your new pet's first visit to the vet. \n" +
                "You also get "+df.format(premiumUserDiscount*100) +"% ($"+df.format(premiumUserDiscount*pet.adoptionFee())+") off your adoption fee!",appName, JOptionPane.QUESTION_MESSAGE,icon);
    }

    //Part 2.7
    /**
     * a method to load and read the premium user data file, adding contents to the Map field
     * @return true if file loads correctly, false if an error occurs
     */
    private boolean loadPremiumData() {
        List<String> eachUser;
        try {
            eachUser = Files.readAllLines(Path.of(premiumUserDataFile));
        }catch (IOException e){
            return false;
        }
        for (int i=1;i<eachUser.size();i++) {
            String[] elements = eachUser.get(i).split(",");

            String phoneNumber=null;
            if(isValidPhoneNumber(elements[2])) phoneNumber=elements[2];
            else{
                System.out.println("Error in file. Phone number could not be parsed for geek on line "+(i+1)+". Terminating.");
                System.exit(0);
            }
            premiumUsers.put(elements[0],new Person(elements[1],phoneNumber,elements[0]));
        }
        return true;
    }
}
