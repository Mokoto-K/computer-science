/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * class to instantiate Dog class, collect user's desired dog info, and determine which Dogs are suitable for adoption,
 */
public class AdoptionRequest {
    //fields
    private static int userMinAge = -1;
    private static int userMaxAge = -1;

    /**
     * reads dog info from a file, creating Dog objects with the data, and adding the Dog objects to an ArrayList
     * collects user information on preferred dog characteristics, then compares these against the Dogs in the ArrayList
     * outputs a list of Dogs that match the user's preferences
     * @param args none required
     */
    public static void main(String[] args) {
        //use loadDogData to read the data, creating and storing the Dog objects in a Set
        Map<Integer, Dog> allDogs = loadDogData("./allDogs.txt");

        //use the setter from Dog to change the de-sexed status. Because we've used a Map, we don't have to loop through to locate the right dog
        Dog dogToUpdate = allDogs.get(989343556);
        //use print statements to visualise what is happening, i.e., check whether the dog is de-sexed
        System.out.println("De-sexed status is: "+dogToUpdate.isDeSexed());
        dogToUpdate.setDeSexed(true);
        //after you've updated it, check that it worked the way you intended
        System.out.println("De-sexed status is: "+allDogs.get(989343556).isDeSexed());

        //use getUserInput() to get the user's filter data
        Dog dreamDog = getUserInput();

        //output all dogs that are of the correct breed
        System.out.println("Dogs with matching breed:");
        //create a HashSet of the all Dogs (the values in the Map)
        Set<Dog> allCandidates = new HashSet<>(allDogs.values());
        //pass the set into the getMatchingDogsBreed method
        Set<Dog> matching = getMatchingDogsBreed(allCandidates,dreamDog);
        for(Dog d:matching) System.out.println(d.getName()+" ("+d.getMicrochipNumber()+") is "+d.getAge()+" years old. De-sexed: "+d.isDeSexed() +". Sex: "+d.getSex()+".");

        //output all dogs that are of the correct breed and within the age range
        System.out.println("\nDogs with matching breed, within age range:");
        matching = getMatchingDogsAge(matching,userMinAge,userMaxAge);
        for(Dog d:matching) System.out.println(d.getName()+" ("+d.getMicrochipNumber()+") is "+d.getAge()+" years old. De-sexed: "+d.isDeSexed() +". Sex: "+d.getSex()+".");

        //output all dogs that are of the correct breed and sex, and are within the age range
        System.out.println("\nDogs with matching breed, within age range with matching sex:");
        matching = getMatchingDogsSex(matching,dreamDog);
        for(Dog d:matching) System.out.println(d.getName()+" ("+d.getMicrochipNumber()+") is "+d.getAge()+" years old. De-sexed: "+d.isDeSexed() +". Sex: "+d.getSex()+".");

        //output all dogs that are of the correct breed and sex, meet the de-sexed/not de-sexed requirements and are within the age range
        System.out.println("\nDogs that meet all criteria:");
        matching = getMatchingDogsDeSexed(matching,dreamDog);
        for(Dog d:matching) System.out.println(d.getName()+" ("+d.getMicrochipNumber()+") is "+d.getAge()+" years old. De-sexed: "+d.isDeSexed() +". Sex: "+d.getSex()+".");
    }

    /**
     * a method used to get the user to enter their preferred breed, sex, age range and de-sexed status
     * @return a Dog object representing the user's desired dog features
     */
    public static Dog getUserInput(){
        //get user preferences for a dream dog they'd like to adopt
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Please enter your preferred breed: ");
        String breed = keyboard.nextLine().toLowerCase(); //implement input validation to ensure user input isn't an empty String

        System.out.println("Please enter your preferred sex: ");
        String sexMaleFemale = keyboard.nextLine(); //implement input validation
        char sex;
        if(sexMaleFemale.equalsIgnoreCase("male")) sex = 'M';
        else sex = 'F';

        System.out.println("What is the minimum age you'd like to adopt? ");
        while(userMinAge==-1){
            try{
                userMinAge = keyboard.nextInt();
                keyboard.nextLine(); //use this to 'use-up' the /n generated when you click 'enter'
            }catch (NumberFormatException e){
                System.out.println("Please enter a number greater than or equal to 0");
            }
        }

        System.out.println("What is the maximum age you'd like to adopt? ");
        while(userMaxAge<userMinAge){
            try{
                userMaxAge = keyboard.nextInt();
                keyboard.nextLine(); //use this to 'use-up' the /n generated when you click 'enter'
            }catch (NumberFormatException e){
                System.out.println("Please enter a number greater than or equal to "+userMinAge);
            }
        }

        System.out.println("Would you prefer the dog to be de-sexed? (yes/no)");
        String deSexedStatus = keyboard.nextLine();
        boolean deSexed = deSexedStatus.equalsIgnoreCase("yes");

        //create a new Dog object containing the user's data. The unused 'dummy' arguments hint that we're not using the Dog class correctly
        //when we cover encapsulation in more detail, you will learn to recognise when to create a separate class, e.g. DreamDog
        return new Dog("",0,breed,sex,0,deSexed);
    }

    /**
     * method read to read a file, creating a dataset of Dog objects from the file contents
     * @param filePath a String representing the relative path of the data file
     * @return a Map of Dog objects derived from the data in the file
     */
    public static Map<Integer,Dog> loadDogData(String filePath){
        //we use a Map, so that we can locate a dog simply using its microchip number
        Map<Integer,Dog> allDogs = new HashMap<>();
        Path path = Path.of(filePath);
        //you can use this as an alternative to loading the file contents as a String and splitting on new line
        List<String> fileContents = null;
        //handle all exceptions
        try{
            fileContents = Files.readAllLines(path);
        }catch (IOException io){
            System.out.println("File could not be loaded. "+ io.getMessage());
            System.exit(0); //terminate the program
        }

        //loop through the contents of the file, skipping the first line
        for(int i=1;i<fileContents.size();i++){
            //split the dog info into elements
            String[] dogInfo = fileContents.get(i).split(",");
            String name = dogInfo[0];
            int microchipNumber = Integer.parseInt(dogInfo[1]);
            char sex;
            if(dogInfo[2].equalsIgnoreCase("male")) sex = 'M';
            else sex = 'F';

            boolean deSexed = dogInfo[3].equalsIgnoreCase("yes");
            int age=-1;
            //more exception handling
            try {
                age = Integer.parseInt(dogInfo[4]);
            }catch (NumberFormatException e){
                System.out.println("Age could not be loaded: "+e.getMessage());
            }
            String breed = dogInfo[5].toLowerCase();

            //instantiate the Dog class, initialising fields with the file data
            Dog d = new Dog(name,microchipNumber,breed,sex,age,deSexed);
            //add the Dog object to the ArrayList
            allDogs.put(microchipNumber,d);
        }
        return allDogs;
    }

    /**
     * use to determine which dogs in a collection are of the breed preferred by the user
     * @param allDogs a Set of Dog objects
     * @param preference a Dog object representing a user's dream dog
     * @return a Set of Dogs that match the user's requirements (correct breed)
     */
    public static Set<Dog> getMatchingDogsBreed(Set<Dog> allDogs, Dog preference){
        Set<Dog> matching = new HashSet<>();
        for(Dog dog:allDogs){
            if(dog.sameBreed(preference)) matching.add(dog);
        }
        return matching;
    }

    /**
     * use to determine which dogs in a collection are of the sex preferred by the user
     * @param allDogs a Set of Dog objects
     * @param preference a Dog object representing a user's dream dog
     * @return a Set of Dogs that match the user's requirements (correct sex)
     */
    public static Set<Dog> getMatchingDogsSex(Set<Dog> allDogs, Dog preference){
        Set<Dog> matching = new HashSet<>();
        for(Dog dog:allDogs){
            if(dog.sameSex(preference)) matching.add(dog);
        }
        return matching;
    }

    /**
     * use to determine which dogs in a collection fall within the age range specified by the user
     * @param allDogs a Set of Dog objects
     * @param min the minimum age the user is willing to adopt
     * @param max the maximum age the user is willing to adopt
     * @return a Set of Dogs that match the user's requirements (within age range)
     */
    public static Set<Dog> getMatchingDogsAge(Set<Dog> allDogs, int min, int max){
        Set<Dog> matching = new HashSet<>();
        for(Dog dog:allDogs){
            if(dog.withinAgeRange(min,max)) matching.add(dog);
        }
        return matching;
    }

    /**
     * use to determine which dogs in a collection have the de-sexed characteristic sought by the user
     * @param allDogs a Set of Dog objects
     * @param preference a Dog object representing a user's dream dog
     * @return a Set of Dogs that match the user's requirements (de-sexed/not)
     */
    public static Set<Dog> getMatchingDogsDeSexed(Set<Dog> allDogs, Dog preference){
        Set<Dog> matching = new HashSet<>();
        for(Dog dog:allDogs){
            if(dog.sameDeSexed(preference)) matching.add(dog);
        }
        return matching;
    }

}
