/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

/**
 * class used to create Dog objects, with methods to determine if Dog fits users adoption request
 */

public class Dog {
    //class fields - final because they are only initialised once (in the constructor)
    private final String name;
    private final int microchipNumber;
    private final String breed;
    private final char sex;
    private final int age;
    //de-sexed is not final, because a dog's de-sexed status can change, as provided for by the setter
    private boolean deSexed;

    /**
     * constructor used to create Dog objects
     * @param name the dog's name
     * @param microchipNumber a unique 9 digit number
     * @param breed the dog's breed
     * @param sex the dog's sex
     * @param age the dog's age in years
     * @param deSexed the dog's current de-sexed status
     */
    public Dog(String name, int microchipNumber,String breed, char sex, int age, boolean deSexed){
        this.name=name;
        this.microchipNumber=microchipNumber;
        this.breed=breed;
        this.sex=sex;
        this.age=age;
        this.deSexed=deSexed;
    }

    //getters - no need for very detailed javadoc
    public String getName() {
        return name;
    }
    public int getMicrochipNumber() {
        return microchipNumber;
    }
    public String getBreed() {
        return breed;
    }
    public int getAge() {
        return age;
    }
    public char getSex() {
        return sex;
    }
    //boolean getters usually start with is instead of get
    public boolean isDeSexed() {
        return deSexed;
    }

    /**
     * use to change de-sexed status of Dog
     * @param deSexed true if de-sexed/false if not
     */
    public void setDeSexed(boolean deSexed) {
        this.deSexed = deSexed;
    }

    /**
     * determines whether 2 Dog objects are the same breed
     * @param dog a Dog object
     * @return true if same breed, false if not
     */
    public boolean sameBreed(Dog dog){
        return breed.equals(dog.getBreed()); //use equals for String comparison
    }

    /**
     * determines whether 2 Dog objects have the same sex
     * @param dog a Dog object
     * @return true if sex fields are the same, false if not
     */
    public boolean sameSex(Dog dog){
        return sex == dog.getSex(); //use == for boolean comparison
    }

    /**
     * determines whether the Dog's age falls within a range
     * @param min lowest age user is willing to adopt
     * @param max greatest age user is willing to adopt
     * @return true if Dog's age is within range, false if greater or less than max/min
     */
    public boolean withinAgeRange(int min, int max){
        return this.age >= min && this.age <= max;
    }

    /**
     * determines whether 2 Dog objects have the same de-sexed status
     * @param dog a Dog object
     * @return true if de-sexed status matches false if different
     */
    public boolean sameDeSexed(Dog dog){
        return this.deSexed == (dog.isDeSexed());
    }
}
