/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

import javax.swing.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class FindADog {

    //fields
    private final static String appName = "Pinkman's Pets Dog Finder";
    private final static String filePath = "./allDogs.txt";
    private final static String iconPath = "./icon.jpg";

    /**
     * main method used to allow the user to search Pinkman's database of dogs, and place an adoption request
     * @param args none required
     */
    public static void main(String[] args) {
        //use the loadDogs method to load up the data in the allDogs file into an AllDogs database object
        AllDogs allDogs = loadDogs();
        //Just for fun! Here is how you make a custom icon :)
        ImageIcon icon = new ImageIcon(iconPath);

        //Welcome user and get their input
        JOptionPane.showMessageDialog(null, "Welcome to Pinkman's Pets Dog Finder!\n\tTo start, click OK.", appName, JOptionPane.QUESTION_MESSAGE, icon);

        //call getUserCriteria to generate a Dog object representing the user's 'dream' dog
        Dog dogCriteria = getUserCriteria();
        //search for a Dog that matches the criteria, using the findMatch method in the AllDogs class
        Dog potentialMatch = allDogs.findMatch(dogCriteria);

        //if a matching Dog has been found, print the Dog's data, and give the user the option to adopt
        if (potentialMatch != null) {
            String adopt = JOptionPane.showInputDialog(null, "Match found!!\n\nWould you like to adopt " + potentialMatch.getName() +
                    " (" + potentialMatch.getMicrochipNumber() + ")?", appName, JOptionPane.QUESTION_MESSAGE);
            if(adopt==null) System.exit(0);
            if (adopt.equals("yes")) {
                Person applicant = getUserDetails();//if the person wants to adopt, get them to enter their details
                writeAdoptionRequestToFile(applicant, potentialMatch); //write the Person and Dog info to the file
                JOptionPane.showMessageDialog(null, "Thank you! Your adoption request has been submitted. " +
                        "One of our friendly staff will be in touch shortly.", appName, JOptionPane.QUESTION_MESSAGE, icon);
            } else {//if the person doesn't want to adopt, output an appropriate message
                JOptionPane.showMessageDialog(null, "That's really sad. We're sure " + potentialMatch.getName()
                                + " would make a wonderful furry friend. Please reconsider and come back again if you change your mind.",
                        appName, JOptionPane.QUESTION_MESSAGE, icon);
            }
            //if no match was found, output an appropriate message
        } else JOptionPane.showMessageDialog(null, "Unfortunately none of our pooches meet your criteria :(" +
                "\n\tTo exit, click OK.", appName, JOptionPane.QUESTION_MESSAGE, icon);
        System.exit(0);
    }

    /**
     * method to load all dog data from file, storing it as Dog objects in an instance of AllDogs
     * @return an AllDogs object - functions as database of Dogs, with associated methods
     */
    private static AllDogs loadDogs() {
        //create an instance of the AllDogs class
        AllDogs allDogs = new AllDogs();
        //load the file
        Path path = Path.of(filePath);

        //load the file data as a List of Strings (each String is one dog's info)
        List<String> dogData = null;
        try{ //ensure appropriate exception handling
            dogData = Files.readAllLines(path);
        }catch (IOException io){
            System.out.println("Could not load the file. \nError message: "+io.getMessage());
            System.exit(0);
        }

        //file data format: name,microchip no,sex,deSexed,age(years),breed
        for (int i=1;i<dogData.size();i++) {
            String[] elements = dogData.get(i).split(",");
            String name = elements[0];
            long microchipNumber = 0;
            try{
                microchipNumber = Long.parseLong(elements[1]);
            }
            catch (NumberFormatException n){
                System.out.println("Error in file. Microchip number could not be parsed for dog on line "+(i+1)+". Terminating. \nError message: "+n.getMessage());
                System.exit(0);
            }
            String sex = elements[2];
            String deSexed = elements[3];

            int age = 0;
            try{
                age = Integer.parseInt(elements[4]);
            }catch (NumberFormatException n){
                System.out.println("Error in file. Age could not be parsed for dog on line "+(i+1)+". Terminating. \nError message: "+n.getMessage());
                System.exit(0);
            }
            String breed = elements[5];

            //create a Dog object for each line in the file (except the first)
            Dog dog = new Dog(name, microchipNumber,age, breed, sex, deSexed);
            //add the Dog to the allDogs object
            allDogs.addDog(dog);
        }
        return allDogs;
    }

    /**
     * generates JOptionPanes requesting user input for dog breed, sex, de-sexed status and age
     * @return a Dog object representing the user's desired dog criteria
     */
    private static Dog getUserCriteria(){
        //ask the user to input their search criteria
        String breed;
        do {
            breed = JOptionPane.showInputDialog(null, "Please enter your preferred breed.", appName, JOptionPane.QUESTION_MESSAGE);
            if(breed==null) System.exit(0); //if the user closes/cancels the dialog, exit normally
        }while (breed.length()==0);

        //ask the user to enter either male or female (include input validation)
        String sex;
        do{
            sex = JOptionPane.showInputDialog(null, "Would you like your dog to be male or female?", appName, JOptionPane.QUESTION_MESSAGE);
            if(sex==null) System.exit(0); //if the user closes/cancels the dialog, exit normally
        } while (!sex.equalsIgnoreCase("male") && !sex.equalsIgnoreCase("female"));

        //ask the user select whether they want their pet de-sexed or not
        String deSexed;
        do{
            deSexed = JOptionPane.showInputDialog(null, "Would you like your dog to be de-sexed or not(yes/no)?", appName, JOptionPane.QUESTION_MESSAGE);
            if(deSexed==null) System.exit(0); //if the user closes/cancels the dialog, exit normally
        } while (!deSexed.equalsIgnoreCase("yes") && !deSexed.equalsIgnoreCase("no"));

        //request that the user enters their preferred age
        int age;
        do {
            String preferredAge = JOptionPane.showInputDialog(null,"How old would you like your pooch to be (years)? ",appName,JOptionPane.QUESTION_MESSAGE);
            if (preferredAge == null) System.exit(0); //if the user closes/cancels the dialog, exit normally
            age = Integer.parseInt(preferredAge);
        }while(age<0);

        //use the user's input to create a Dog object
        return new Dog("", 0, age, breed, sex, deSexed);
    }

    /**
     * method to get user to input name, ph num and email, with appropriate input validation
     * @return a Person object representing the user of the program
     */
    private static Person getUserDetails(){
        String name;
        do {
            name = JOptionPane.showInputDialog(null, "Please enter your full name.", appName, JOptionPane.QUESTION_MESSAGE);
            if(name==null) System.exit(0); //if the user closes/cancels the dialog, exit normally
        }while (!name.contains(" ")); //full name contains whitespace

        String phoneNumberInput;
        long phoneNumber;
        do {
            phoneNumberInput = JOptionPane.showInputDialog(null,"Please enter your phone number. Format: 0412838475",appName,JOptionPane.QUESTION_MESSAGE);
            if (phoneNumberInput == null) System.exit(0); //if the user closes/cancels the dialog, exit normally
            phoneNumber = Long.parseLong(phoneNumberInput);
        }while(phoneNumberInput.length()!=10); //ph number must be 10 digits long

        String email;
        do {
            email = JOptionPane.showInputDialog(null, "Please enter your email address.", appName, JOptionPane.QUESTION_MESSAGE);
            if(email==null) System.exit(0); //if the user closes/cancels the dialog, exit normally
        }while (!email.contains("@")); //email must contain @

        //use those details to create a Person object
        return new Person(name, phoneNumber, email);
    }

    /**
     * provides Pinkman's Pets with a file containing the user's adoption request
     * @param person a Person object representing the user
     * @param dog a Dog object representing the dog that the user wants to adopt
     */
    private static void writeAdoptionRequestToFile(Person person, Dog dog) {
        //create a String to represent the filepath of the new file we'll be writing
        String filePath = person.name().replace(" ","_")+"_adoption_request.txt";
        //using the above String, create a Path object
        Path path = Path.of(filePath);
        //create the String which will be written to the file
        String lineToWrite = person.name()+" wishes to adopt "+dog.getName()+" ("+dog.getMicrochipNumber()+
                "). Their phone number is 0"+person.phoneNumber()+" and their email address is "+person.emailAddress();
        try {
            Files.writeString(path, lineToWrite);
        }catch (IOException io){ //handle exceptions appropriately
            System.out.println("File could not be written. \nError message: "+io.getMessage());
            System.exit(0);
        }
    }

}
