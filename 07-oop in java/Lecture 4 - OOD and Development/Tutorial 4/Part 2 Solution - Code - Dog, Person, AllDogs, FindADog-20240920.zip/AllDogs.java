/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

import java.util.ArrayList;
import java.util.List;

public class AllDogs {
    //fields
    private final List<Dog> allDogs = new ArrayList<>();

    //default constructor used, therefore no need to declare it

    //methods
    /**
     * method to add a Dog object to the database (allDogs)
     * @param dog a Dog object
     */
    public void addDog(Dog dog){
        this.allDogs.add(dog);
    }

    /**
     * returns only one Dog - the first that meets all the user's requirements
     * this method should be improved to return a collection of Dog objects
     * @param dogCriteria a Dog object representing a user's preferred Dog
     * @return a Dog object
     */
    public Dog findMatch(Dog dogCriteria){
        for(Dog dog: this.allDogs){
            if(!dog.getBreed().equals(dogCriteria.getBreed())) continue; //if the breeds don't match, skip to the next iteration of the loop
            if(!dog.getSex().equals(dogCriteria.getSex())) continue;
            if(dog.getAge()!= dogCriteria.getAge()) continue; //improve functionality by changing this to an age range rather than a specific value
            if(!dog.isDeSexed().equals(dogCriteria.isDeSexed())) continue;
            return dog;
        }
        return null;
    }

}
