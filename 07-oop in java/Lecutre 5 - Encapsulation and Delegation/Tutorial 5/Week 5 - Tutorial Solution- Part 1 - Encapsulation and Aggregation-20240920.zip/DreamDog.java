//EDIT Part 1.4
/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

public class DreamDog {

    //fields
    private final String breed;
    private final Sex sex;
    private final DeSexed deSexed;
    private final int minAge;
    private final int maxAge;

    /**
     *
     * @param breed String representing the dog's breed
     * @param sex String (male or female)
     * @param deSexed String (yes - de-sexed or no - not de-sexed)
     * @param minAge lowest age user would be willing to adopt
     * @param maxAge highest age user would be willing to adopt
     */
    public DreamDog(String breed, Sex sex, DeSexed deSexed, int minAge, int maxAge) {
        this.breed = breed;
        this.sex = sex;
        this.deSexed = deSexed;
        this.minAge = minAge;
        this.maxAge = maxAge;
    }

    /**
     * @return the dog's breed
     */
    public String getBreed() {
        return breed;
    }

    /**
     * @return the dog's sex (male or female)
     */
    public Sex getSex() { return sex;}

    /**
     * @return the dog's de-sexed status
     */
    public DeSexed isDeSexed() { return deSexed; }

    /**
     * @return a 'dream' dog's min age
     */
    public int getMinAge() {
        return minAge;
    }
    /**
     * @return a 'dream' dog's max age
     */
    public int getMaxAge() {
        return maxAge;
    }
}