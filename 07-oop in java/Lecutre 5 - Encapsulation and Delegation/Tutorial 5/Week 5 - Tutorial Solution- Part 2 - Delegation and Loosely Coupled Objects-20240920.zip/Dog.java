/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

import java.text.DecimalFormat;

public class Dog {
    //fields
    private final String name;
    private final long microchipNumber;
    private final int age;
    //EDIT Part 1.2 - add field
    private final double adoptionFee;
    private final DreamDog dreamDog;

    //EDIT Part 4.2.1
//    /**
//     * constructor to create a Dog object
//     * @param name the dog's name
//     * @param microchipNumber the dog's microchip number - unique 9-digit number
//     * @param age the dog's age in years
//     * @param adoptionFee a double representing the adoption fee for this dog
//     * @param breed String representing the dog's breed
//     * @param sex String (male or female)
//     * @param deSexed String (yes - de-sexed or no - not de-sexed)
//     * @param purebred Enum Purebred representing yes/no/na
//     */
//    public Dog(String name, long microchipNumber, int age, double adoptionFee, //EDIT Part 1.2
//               String breed, Sex sex, DeSexed deSexed, Purebred purebred){ //EDIT Part 3.5
//        this.name=name;
//        this.microchipNumber=microchipNumber;
//        this.age=age;
//        this.adoptionFee=adoptionFee;//EDIT Part 1.2 - initialise var
//        this.dreamDog = new DreamDog(breed,sex,deSexed,purebred,0,0); //EDIT Part 3.5
//    }

    //EDIT Part 4.2.1 - remove DreamDog implementation details from Dog constructor
    /**
     * constructor to create a Dog object
     * @param name the dog's name
     * @param microchipNumber the dog's microchip number - unique 9-digit number
     * @param age the dog's age in years
     * @param adoptionFee a double representing the adoption fee for this dog
     */
    public Dog(String name, long microchipNumber, int age, double adoptionFee, DreamDog dreamDog){
        this.name=name;
        this.microchipNumber=microchipNumber;
        this.age=age;
        this.adoptionFee=adoptionFee;
        this.dreamDog = dreamDog;
    }

    //getters
    /**
     * @return the dog's name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the dog's microchip number - unique 9-digit number
     */
    public long getMicrochipNumber() {
        return microchipNumber;
    }

    /**
     * @return the dog's age in years
     */
    public int getAge() {
        return age;
    }

    //EDIT Part 1.2 - getter
    /**
     * @return a double representing the adoption fee for this dog
     */
    public double getAdoptionFee() {
        return adoptionFee;
    }

    /**
     * @return the DreamDog object representing a real's dog's dream characteristics
     */
    public DreamDog getDreamDog() {
        return dreamDog;
    }

    //EDIT Part 2.3 - create a getDogDescription method
    /**
     * method to return a description of a Dog, including all its unique and generic features
     * @return String
     */
    public String getDogDescription(){
        DecimalFormat df = new DecimalFormat("0.00");
        return this.getName()+" ("+this.getMicrochipNumber()+ ") is a "+this.getAge()+" year old "+
                this.getDreamDog().getDreamDogDescription()+ ".\n > Adoption fee: $"+df.format(this.getAdoptionFee())+"\n";
    }
}