/**
 * @author Dr Andreas Shepley (asheple2@une.edu.au | andreashepley01@gmail.com)
 * created for COSC120 (Trimester 1 2022)
 * last revised: Trimester 1 2024
 */

public class DreamDog {

    //fields
    private final String breed;
    private final Sex sex;
    private final DeSexed deSexed;
    private final int minAge;
    private final int maxAge;
    //EDIT 3.4 - add the purebred field
    private final Purebred purebred;

    /**
     *
     * @param breed String representing the dog's breed
     * @param sex String (male or female)
     * @param deSexed String (yes - de-sexed or no - not de-sexed)
     * @param purebred Enum Purebred representing yes/no/na
     * @param minAge lowest age user would be willing to adopt
     * @param maxAge highest age user would be willing to adopt
     */
    public DreamDog(String breed, Sex sex, DeSexed deSexed, Purebred purebred, //EDIT Part 3.4
                    int minAge, int maxAge) {
        this.breed = breed;
        this.sex = sex;
        this.deSexed = deSexed;
        //EDIT Part 3.4 - initialise the purebred field
        this.purebred=purebred;
        this.minAge = minAge;
        this.maxAge = maxAge;
    }

    /**
     * @return the dog's breed
     */
    public String getBreed() {
        return breed;
    }

    /**
     * @return the dog's sex (male or female)
     */
    public Sex getSex() { return sex;}

    /**
     * @return the dog's de-sexed status
     */
    public DeSexed isDeSexed() { return deSexed; }

    //EDIT 3.4 - create a getter for purebred
    /**
     * @return Purebred constant yes (purebred), no(not purebred) or NA
     */
    public Purebred getPurebred() {
        return purebred;
    }

    /**
     * @return a 'dream' dog's min age
     */
    public int getMinAge() {
        return minAge;
    }
    /**
     * @return a 'dream' dog's max age
     */
    public int getMaxAge() {
        return maxAge;
    }

    //EDIT Part 2.2 - create a getDreamDogDescription method
    /**
     * @return a formatted description of generic DreamDog features
     */
    public String getDreamDogDescription(){
        //EDIT 3.4 - print purebred only if relevant
        if(this.purebred.equals(Purebred.YES)) return this.getSex()+ " purebred " +this.getBreed()+".\n > De-sexed: "+this.isDeSexed();
        return this.getSex()+ " " +this.getBreed()+".\n > De-sexed: "+this.isDeSexed();
    }

    //EDIT Part 4.3.1 and 4.3.2:
    /**
     * method to compare two DreamDog objects against each other for compatibility
     * @param dogCriteria an imaginary dog representing the user's criteria
     * @return true if matches, false if not
     */
    public boolean compareDreamDogs(DreamDog dogCriteria) {
        if (!this.getBreed().equals(dogCriteria.getBreed())) return false;
        if (!this.getSex().equals(dogCriteria.getSex())) return false;
        if (!this.isDeSexed().equals(dogCriteria.isDeSexed())) return false;
        if (dogCriteria.getPurebred().equals(Purebred.YES) || dogCriteria.getPurebred().equals(Purebred.NO)){
            return this.getPurebred().equals(dogCriteria.getPurebred());
        }
        return true;
    }
}