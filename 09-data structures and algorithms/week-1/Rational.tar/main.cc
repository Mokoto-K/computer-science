#include "Rational.h"
using namespace std;

int main()
{
	// Testing the rational number class.

	// Testing the constructors.
	Rational a;
	Rational b(4,3);
	Rational c(5,10);

	// Testing the overloaded stream insertion operator.
	cout << a << endl;
	cout << b << endl;
	cout << c << endl;

	// Testing the overloaded + operator.
	Rational d = b + c;

	cout << d << endl;

	return 0;
}
