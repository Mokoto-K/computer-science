// Bank_Account.h (INTERFACE)

#include <string>

class Bank_Account {
public:
	Bank_Account(): account_number(), balance() {  }	
	Bank_Account(std::string, int, double);

	void set_balance(double);
	void set_account_number(int);
	void set_customer_name(std::string);
	std::string get_customer_name() const;
	int get_account_number() const;
	double get_balance() const;
private:
	std::string customer_name;
	int account_number;
	double balance;
};

// A class derived from Bank_Account.
class Credit_Account: public Bank_Account {
public:
	Credit_Account(): Bank_Account(), credit_balance() {  };
	Credit_Account(std::string, int, double, double);
	void set_credit_balance(double);
	double get_credit_balance() const;
private:
	double credit_balance;
};
