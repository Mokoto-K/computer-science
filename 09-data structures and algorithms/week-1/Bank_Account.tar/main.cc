// main.cc (TESTING THE CLASS)

#include <iostream>
#include "Bank_Account.h"
using namespace std;

int main()
{
	// OBJECT INSTANTIATION
	Bank_Account customer1;
	Bank_Account customer2("David", 123, 100.0);

	// OUTPUT VALUES FOR CUSTOMER 1
	cout << "Name: " << customer1.get_customer_name() << endl;
	cout << "Account number: " << customer1.get_account_number() << endl;
	cout << "Balance: " << customer1.get_balance() << endl;

	// OUTPUT VALUES FOR CUSTOMER 2
	cout << "Name: " << customer2.get_customer_name() << endl;
	cout << "Account number: " << customer2.get_account_number() << endl;
	cout << "Balance: " << customer2.get_balance() << endl;

	// TESTING SET MEMBER
	customer2.set_balance(200.0);
	cout << "Balance: " << customer2.get_balance() << endl;

	Credit_Account customer3;
	cout << "Name: " << customer3.get_customer_name() << endl;
	cout << "Account number: " << customer3.get_account_number() << endl;
	cout << "Balance: " << customer3.get_balance() << endl;
	cout << "Credit Balance: " << customer3.get_credit_balance() << endl;

	Credit_Account customer4("Harry", 146, 300.0, 50.0);
	cout << "Name: " << customer4.get_customer_name() << endl;
	cout << "Account number: " << customer4.get_account_number() << endl;
	cout << "Balance: " << customer4.get_balance() << endl;
	cout << "Credit Balance: " << customer4.get_credit_balance() << endl;

	return 0;
}
