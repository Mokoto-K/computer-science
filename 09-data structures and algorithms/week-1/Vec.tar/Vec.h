// Vec.h
// A minimal 1D array class to demonstrate memory management.

class Vec {
public:
	Vec(); 
	Vec(int);
	~Vec();
	Vec(const Vec&);
	Vec& operator=(const Vec&);
	double& operator[](int);
private:
	int array_size;
	double* pointer_to_data;
};
