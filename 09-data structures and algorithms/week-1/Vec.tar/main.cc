// main.cc
#include <iostream>
#include "Vec.h"
using namespace std;

int main()
{
	Vec v1(5);

	cout << v1[0] << endl;

	v1[0] = 1.0;

	Vec v2(v1);

	cout << v1[0] << " " << v2[0] << endl;

	v2[0] = 2.0;

	cout << v1[0] << " " << v2[0] << endl;

	Vec v3(5);

	v3 = v2;

	cout << v3[0] << " " << v3[1] << endl;

	return 0;
}
