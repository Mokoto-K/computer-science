// Vec.cc
#include "Vec.h"

Vec::Vec()
{
	array_size = 0;
	pointer_to_data = 0;
}

// Constructor
Vec::Vec(int a)
{
	array_size = a;

	// Allocate new memory for array.
	pointer_to_data = new double[array_size];

	// Initialize array.
	for (int i = 0; i != array_size; ++i) {
		pointer_to_data[i] = 0.0;
	}
}
// Overloading the copy constructor.
Vec::Vec(const Vec& vec_to_copy)
{
	array_size = vec_to_copy.array_size;

	// Allocate new memory for array.
	pointer_to_data = new double[array_size];

	// Copy data across.
	for (int i = 0; i != array_size; ++i) {
		pointer_to_data[i] = vec_to_copy.pointer_to_data[i];
	}
}
// Destructor
Vec::~Vec()
{
	// Free array memory
	delete[] pointer_to_data;
} 
// Overloading the assignment operator.
Vec& Vec::operator=(const Vec& rhs)
{
	// Check for self-assignment.
	if (&rhs != this) {
		// Free lhs array memory.
		delete[] pointer_to_data;
		// Allocate new memory for lhs array.
		pointer_to_data = new double[array_size];
		// Copy rhs data across.
		for (int i = 0; i != array_size; ++i) {
			pointer_to_data[i] = rhs.pointer_to_data[i];
		}
	}		

	return *this;
}
// Overloading the index operator
double& Vec::operator[](int i)
{
	return pointer_to_data[i];
}
